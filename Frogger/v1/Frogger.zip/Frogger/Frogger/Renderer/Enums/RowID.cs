﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Frogger.Renderer.Enums
{
    public enum RowID
    {
        Zero,
        First,
        Second,
        Third,
        Fourth,
        Fifth,
        Sixth,
        Seventh,
        Eighth,
        Ninth,
        Tenth,
        Eleventh,
        Twelfth,
        Thirteenth,
        Fourteenth,
        Fifteenth
        /*
        За сега толкова
        Sixteenth,
        Seventeenth,
        Eighteenth,
        Nineteenth,
        Twentieth*/
    }
}
