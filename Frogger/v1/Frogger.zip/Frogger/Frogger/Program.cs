﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Frogger.Renderer;
using Frogger.Utils;

namespace Frogger
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Tester.Tester.RunTest();
            Engine.Engine.Run();

        }
    }
}