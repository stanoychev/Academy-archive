﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Frogger.Objects.Enums
{
    public enum VehicleDirection
    {
        Left = -1,
        Freeze,
        Right
    }
}
