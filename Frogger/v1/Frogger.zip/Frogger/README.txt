Authors:
Martin Ivanov,
Nikola Stanoychev,
Radoslav Georgiev and
Zlatan Angelov

About:
The project aims to recreate the famous Frogger game. A Frog starts its way through the road from the bottom part of the screen and needs to cross it avoiding collisions
with the vehicles along the way.